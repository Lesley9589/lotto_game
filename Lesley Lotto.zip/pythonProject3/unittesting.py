from login import *
import unittest

class Test_eom(unittest):

    def ages(self):
        assert entry10 == range(18, 85), "Able to PLay"
        assert entry10 == range(0, 17), "Unable to PLay"